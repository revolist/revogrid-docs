# Local verification — GRID-03

Verified 10 November 2026, Node 24.22.1, Chromium through Playwright.

## Executed checks

From this starter:

- `pnpm build`: TypeScript and production Vite build passed with official Pro/Pivot trials 4.0.6, Core 4.31.4 and Revo UI 4.0.6.
- `pnpm test`: 5 tests passed. They cover real SQLite query cases, strict query/response validation, count/page snapshot consistency under a second connection's write, a real HTTP endpoint/body limit, and the Pro loader's skip/take mapping, signal forwarding and detached request metadata.
- `PORT=49303 pnpm start`: serves the compiled client and SQL API on one loopback origin.

From the docs root, `../node_modules/.bin/playwright test --config playwright.article-pagination.config.ts`: 6 browser scenarios passed twice (12 executions). They cover:

- One real Pro PaginationPlugin panel, next/page-number selection, server offsets, row-count configuration and reset. There is no custom controller, pager or grid-source assignment.
- Held earlier Needle delivery cannot replace Boundary's four rows or its Pivot chart. Failed page delivery clears the grid and chart; Retry reloads the current plugin page (offset 10).
- A controlled shrinking HTTP result clamps the plugin to the last valid page; no-match results disable navigation.
- Compound paid/shipped filters, minimum amount, stable tied ordering at page size 1, usable Previous/Next at 390px dark width and no page overflow.
- Matching shared status badges in filters/grid and native Pivot counts (3 Pending, 3 Paid, 2 Shipped, 2 Cancelled initially). Filtered subsets retain orange Paid/blue Shipped. Paging updates the chart and empty results hide it.
- Apply/Clear/Rows per page share a baseline and 32px height. All visible application HTML buttons use Revo UI.
- Actual shared calendar day selection, keyboard date entry, reset, invalid and inverted range validation, and a bounded mobile popup. A Los Angeles browser selects February 1 through excluded March 1; the request still carries exact UTC-midnight boundaries and returns only ORD-0901/0902.

The original broader walkthrough also checked 51 null totals, literal percent/underscore searches, and debounce cancellation. SQL/query tests retain those cases.

## Evidence

Tracked assets: `../../public/blog/server-side-data-grid/initial.png`, `needle.png`, `retry.png`, `datepicker.png`, and `request-race.webm`.
Download: `../../public/examples/server-side-data-grid.zip`.
Additional local proof is in ignored `../../output/articles-02-03/` and `../../.playwright-mcp/`.
Article: `../../blog/javascript-data-grid-server-side-pagination-sorting-filtering.md`.

The docs production build and 8 blog metadata/rendered checks were run from the docs root. The ZIP passed CRC, an isolated frozen-lockfile install and typecheck.

## Limits

The chart explicitly summarizes the current accepted page; it does not claim aggregates over all matching records. Pivot owns aggregation and rendering; no extra HTTP request downloads the full dataset.

The official packages are commercial trials with their original trial behavior preserved. Licensed use requires licensed packages/registry. The combined trial distribution produces a large-chunk build warning (about 6.3 MB uncompressed JavaScript); this article makes no bundle-size or performance claim.

This fixed-account synthetic SQLite service has no login. Search matching is bounded to ASCII fixtures. Delayed/failed delivery controls are not database outages or benchmarks. The fixture was reconstructed; original JSON byte identity is not claimed. Remote CI and deployment were not tested. Existing docs-preview hydration/CookieYes hostname messages also occur on `/blog/datagrid`; standalone runtime checks are separate.
