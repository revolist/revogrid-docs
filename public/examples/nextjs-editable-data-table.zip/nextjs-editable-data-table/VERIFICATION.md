# Local verification — GRID-02

Verified 10 November 2026, Node 24.22.1, Chromium through Playwright.

## Executed checks

From this starter:

- `NEXT_TELEMETRY_DISABLED=1 pnpm build`: production Next.js compilation and TypeScript passed.
- `pnpm test`: 4 tests passed. They cover raw draft validation and an alternate translation, zero cents, strict server envelopes/types, no writes on rejection, two-connection version conflicts, explicit field reapply, retry after a lost acknowledgement, file-backed restart, plain-object server/client serialization, incoming-host origin checks, and reset/write serialization.
- `DEMO_ACTIONS=1 NEXT_TELEMETRY_DISABLED=1 pnpm start`: production server exercised at `http://127.0.0.1:49302`.

Browser observations:

- Hard navigation renders the server heading and client grid.
- Every visible application button has the Revo UI owner class. The row dropdown, panel, toolbar, alerts, disclosure and confirmation modal use UI public adapters. Dropdown height measured 32px after loading its exported stylesheet.
- An open cell editor disables Save; Escape discards unfinished input and clears editing state. Invalid quantity 0 remains visible; Cancel restores the confirmed row. Zero cents is valid.
- Saving OL-0001 quantity 12→15 returned version 2. Hard reload and a complete server process restart both retained 15/version 2 in SQLite.
- A stale OL-0003 save shows original quantity 6/version 4, local 8, and latest quantity 9/version 5. Explicit reapply preserves remote status confirmed; the following save returns quantity 8/version 6.
- A held response for row A did not replace row B's draft or selection. Cancel restored only B. Reset stayed disabled during the outstanding save.
- A transport response deliberately dropped after real commit preserved the draft; retrying its original version entered conflict review rather than writing twice.
- UI reset confirmation restored all 20 fixture rows. The row selector was operated through the shared dropdown.
- Desktop and 390px dark/light layouts were inspected. The grid scrolls within its container; the page has no horizontal overflow. OS theme changes use the public compact/darkCompact grid themes.

## Evidence

Tracked article assets live in `../../public/blog/nextjs-editable-data-table/`:
`initial.png`, `saved.png`, `conflict.png`, and `save-reload.webm`.
The downloadable source is `../../public/examples/nextjs-editable-data-table.zip`.
Additional local screenshots/recordings and browser tool logs are in the ignored
`../../output/articles-02-03/` and `../../.playwright-mcp/` folders.

The documentation production build and blog metadata/rendered checks were also run from the docs root. The public article is `../../blog/nextjs-editable-data-table.md`.

## Limits

This is a locally verified single-process starter with a fixed synthetic workspace,
not an authenticated public backend. Reconstructed fixtures preserve the retained
walkthrough, not every byte of the missing original JSON. Remote CI, publication
and deployed behavior were not exercised. The shared docs preview emits a hydration
warning and a CookieYes registered-host error; both were reproduced on the existing
`/blog/datagrid` page independently of this article. They do not occur in the standalone starter.
